package Problem2.FontsPackage;

public interface Fonts {
    String getFontName();
}
