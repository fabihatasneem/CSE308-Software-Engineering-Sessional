package Problem2.ParserPackage;

public class CPPParser implements Parser{
    public CPPParser() {
    }

    @Override
    public void parse() {
        System.out.println("C++ file is parsing....");
    }
}
