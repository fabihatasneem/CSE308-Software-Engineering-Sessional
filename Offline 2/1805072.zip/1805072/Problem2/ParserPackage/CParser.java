package Problem2.ParserPackage;

public class CParser implements Parser{
    public CParser() {
    }

    @Override
    public void parse() {
        System.out.println("C file is parsing....");
    }
}
