package Problem2.ParserPackage;

public interface Parser {
    void parse();
}
