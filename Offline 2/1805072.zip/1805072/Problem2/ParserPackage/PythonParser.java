package Problem2.ParserPackage;

public class PythonParser implements Parser{
    public PythonParser() {
    }

    @Override
    public void parse() {
        System.out.println("Python file is parsing....");
    }
}
