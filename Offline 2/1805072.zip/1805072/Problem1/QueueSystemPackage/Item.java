package Problem1.QueueSystemPackage;

public interface Item {
    String getItemName();
    double getItemPrice();
}
