package Problem1.QueueSystemPackage;

abstract class Choice implements Item {
    @Override
    public String getItemName() {
        return null;
    }

    @Override
    public double getItemPrice() {
        return 0;
    }
}
