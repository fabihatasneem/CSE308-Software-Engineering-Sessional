package Problem1.CommunicationPackage.BroadbandService;

import Problem1.CommunicationPackage.Communication;

public abstract class WifiModule extends Communication {
}
