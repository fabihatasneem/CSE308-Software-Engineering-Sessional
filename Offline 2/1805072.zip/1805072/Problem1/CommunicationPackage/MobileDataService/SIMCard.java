package Problem1.CommunicationPackage.MobileDataService;

import Problem1.CommunicationPackage.Communication;

public abstract class SIMCard extends Communication {
}
