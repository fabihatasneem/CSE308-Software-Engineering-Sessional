package Problem1.Factory.DisplayPackage;

public interface Display {
    String getDisplayName();
    double getDisplayPrice();
}
