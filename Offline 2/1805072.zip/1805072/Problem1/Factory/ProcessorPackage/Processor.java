package Problem1.Factory.ProcessorPackage;

public interface Processor {
    String getProcessorName();
    double getProcessorPrice();
}
